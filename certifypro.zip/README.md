# CertifyPro Website

Run with:

npm install
npm run dev